#ifndef __CONTIKI_INIT_NET_H__
#define __CONTIKI_INIT_NET_H__

void print_address(uip_ds6_addr_t *lladdr);

#endif /* __CONTIKI_INIT_NET_H__ */