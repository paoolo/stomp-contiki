
extern int readADC(uint8_t pin);

// Returns celcius * 100
extern int readInternalTemp(void);
